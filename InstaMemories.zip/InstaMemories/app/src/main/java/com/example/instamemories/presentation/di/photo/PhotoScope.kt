package com.example.instamemories.presentation.di.photo

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class PhotoScope