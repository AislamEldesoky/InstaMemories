package com.example.instamemories.data.model.photo

import com.example.instamemories.data.model.photo.Photo

class PhotosList : ArrayList<Photo>()