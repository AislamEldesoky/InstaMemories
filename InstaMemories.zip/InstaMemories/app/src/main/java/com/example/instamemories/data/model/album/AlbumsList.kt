package com.example.instamemories.data.model.album

import com.example.instamemories.data.model.album.Album

class AlbumsList : ArrayList<Album>()