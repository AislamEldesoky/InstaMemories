package com.example.instamemories.data.model.user

import com.example.instamemories.data.model.user.User

class UsersList : ArrayList<User>()